from distutils.core import setup

setup(
  name = 'palyndrome',
  version = '1.0',
  py_modules = [ 'palyndrome' ],

  # metadata
  author = 'Iván',
  author_email = 'imerinro@capgemini.com',
  description = 'La descripción del proyecto',
  license = 'public domain',
  keywords = 'palyndrome numbers math'
  )


